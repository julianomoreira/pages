/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};


var resources = [
];
var symbols = {
"stage": {
   version: "1.0.0",
   minimumCompatibleVersion: "0.1.7",
   build: "1.0.0.185",
   baseState: "Base State",
   initialState: "Base State",
   gpuAccelerate: false,
   resizeInstances: false,
   content: {
         dom: [
         {
            id:'pr-plp-background',
            type:'image',
            rect:['0px','0px','1280px','2416px','auto','auto'],
            fill:["rgba(0,0,0,0)",im+"pr-plp-background.png",'0px','0px']
         },
         {
            id:'tile-hover2',
            type:'image',
            rect:['645px','271px','244px','589px','auto','auto'],
            opacity:0,
            fill:["rgba(0,0,0,0)",im+"tile-hover.png",'0px','0px']
         },
         {
            id:'Ellipse',
            type:'ellipse',
            rect:['393px','316px','28px','28px','auto','auto'],
            borderRadius:["50%","50%","50%","50%"],
            opacity:0.50289916992188,
            fill:["rgba(249,0,0,1.00)"],
            stroke:[0,"rgba(0,0,0,1)","none"]
         }],
         symbolInstances: [

         ]
      },
   states: {
      "Base State": {
         "${_Stage}": [
            ["color", "background-color", 'rgba(255,255,255,1)'],
            ["style", "width", '1280px'],
            ["style", "height", '1000px'],
            ["style", "overflow", 'hidden']
         ],
         "${_pr-plp-background}": [
            ["style", "left", '0px'],
            ["style", "top", '0px']
         ],
         "${_Ellipse}": [
            ["color", "background-color", 'rgba(249,0,0,1.00)'],
            ["style", "top", '365.91px'],
            ["style", "height", '27.950519561768px'],
            ["style", "opacity", '0.50289916992188'],
            ["style", "left", '393.39px'],
            ["style", "width", '27.950519561768px']
         ],
         "${_tile-hover2}": [
            ["style", "top", '271.1px'],
            ["style", "opacity", '0'],
            ["style", "left", '645.34px']
         ]
      }
   },
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1000,
         autoPlay: true,
         timeline: [
            { id: "eid10", tween: [ "style", "${_Ellipse}", "top", '365.91px', { fromValue: '365.91px'}], position: 1000, duration: 0 },
            { id: "eid7", tween: [ "style", "${_Ellipse}", "left", '685.5px', { fromValue: '393.39px'}], position: 0, duration: 1000 },
            { id: "eid18", tween: [ "style", "${_tile-hover2}", "opacity", '0', { fromValue: '0'}], position: 0, duration: 0 },
            { id: "eid17", tween: [ "style", "${_tile-hover2}", "opacity", '0.503174', { fromValue: '0'}], position: 597, duration: 200 },
            { id: "eid13", tween: [ "style", "${_tile-hover2}", "opacity", '1', { fromValue: '0.503174'}], position: 797, duration: 203 }         ]
      }
   }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-11093429");
